vim.opt.guicursor = ""

vim.opt.expandtab = true
vim.opt.shiftwidth = 4
vim.opt.softtabstop = 4
vim.opt.tabstop = 4

vim.opt.rnu = true
vim.opt.nu = true
vim.opt.errorbells = false
vim.opt.autoindent = true
vim.opt.smartindent = true
vim.opt.smartcase = true

vim.opt.wrap = false
vim.opt.mouse = ""

vim.opt.swapfile = false
vim.opt.backup = false
vim.opt.undodir = os.getenv("HOME") .. "/.vim/undodir"
vim.opt.undofile = true

vim.opt.hlsearch = false
vim.opt.incsearch = true


vim.api.nvim_create_autocmd({ 'BufNewFile', 'BufRead' }, {
	pattern = '*.zon',
	command = 'setfiletype zig',
})

vim.api.nvim_create_autocmd({ 'BufNewFile', 'BufRead' }, {
	pattern = '*.metal',
	command = 'setfiletype metal',
})

vim.api.nvim_create_autocmd({ 'BufNewFile', 'BufRead' }, {
	pattern = '*.v',
	command = 'setfiletype coq',
})

vim.api.nvim_create_autocmd({ 'BufNewFile', 'BufRead' }, {
	pattern = '*.m',
	command = 'setfiletype objc',
})

vim.api.nvim_create_autocmd( 'FileType', {
	pattern = {'html', 'css', 'nix', 'json', 'typescript'},
	callback = function()
		vim.cmd [[
		set expandtab
		set shiftwidth=2
		set softtabstop=2
		set tabstop=2
		]]
	end
})

-- vim.api.nvim_create_autocmd( 'FileType', {
--     pattern = '.zig',
--     command = 'setlocal formatoptions-=cro',
-- })

vim.o.background = "dark" -- or "light" for light mode
-- Default options:
vim.cmd("colorscheme rose-pine")
vim.api.nvim_set_hl(0, "Normal", { bg = "NONE" })
vim.api.nvim_set_hl(0, "SignColumn", { bg = "NONE"})
vim.wo.colorcolumn = '80'
vim.api.nvim_set_hl(0, "ColorColumn", {
    bg = "#1f1d2e", -- GUI background color
})
-- Disable Zig formatter
vim.g.zig_fmt_autosave = 0
