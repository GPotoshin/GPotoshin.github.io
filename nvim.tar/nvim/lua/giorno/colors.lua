require("cmp").setup({
    window = {
        completion = {
            scrollbar = false,
        }
    }
})
vim.api.nvim_set_hl(0, 'NormalFloat', {clear, ctermfg = 2}) -- K
vim.api.nvim_set_hl(0, 'FloatBorder', {bg = 'none'})
vim.api.nvim_set_hl(0, "Pmenu", { clear })
vim.api.nvim_set_hl(0, "PmenuSel", { ctermbg = 2, ctermfg = 0})

vim.api.nvim_set_hl(0, "Normal", { ctermfg = 2 }) -- default text
vim.api.nvim_set_hl(0, "Type", { ctermfg = 4 })
vim.api.nvim_set_hl(0, "Statement", { ctermfg = 10 }) -- if, else, etc
vim.api.nvim_set_hl(0, "Constant", { ctermfg = 3 })
vim.api.nvim_set_hl(0, "Special", { ctermfg = 7 })
vim.api.nvim_set_hl(0, "Identifier", { ctermfg = 14 })
vim.api.nvim_set_hl(0, "PreProc", { ctermfg = 10 }) -- use, macros
vim.api.nvim_set_hl(0, "Comment", { ctermfg = 8 })
vim.api.nvim_set_hl(0, "MatchParen", { ctermfg = 0, ctermbg = 11 })
vim.api.nvim_set_hl(0, "SpellBad", { ctermfg = 1})

vim.api.nvim_set_hl(0, "DiagnosticHint", { ctermfg = 5 })

vim.api.nvim_set_hl(0, "ColorColumn", { ctermbg = 8, bg = LightGrey })
vim.api.nvim_set_hl(0, "SignColumn", { clear })
vim.api.nvim_set_hl(0, "LineNr", { ctermfg=2 })

