local dap = require('dap')
local dapui = require('dapui')

vim.keymap.set("n", "<F2>", function() dap.step_into() end)
vim.keymap.set("n", "<F3>", function() dap.step_over() end)
vim.keymap.set("n", "<F4>", function() dap.step_out() end)
vim.keymap.set("n", "<leader>b", function() dap.toggle_breakpoint() end)
vim.keymap.set("n", "<leader>B", function() dap.set_breakpoint(vim.fn.input('Breakpoint condition: ')) end)
vim.keymap.set("n", "<leader>dc", function() dap.continue() end)
vim.keymap.set("n", "<leader>dl", function() dap.set_breakpoint(nil, nil, vim.fn.input('Log message: ')) end)
vim.keymap.set("n", "<leader>dr", function() dap.repl.open() end)
vim.keymap.set("n", "<leader>du", function() dapui.open() end)


require('dapui').setup()

dap.adapters.lldb = {
  type = 'executable',
  command = '/run/current-system/sw/bin/lldb-dap',
  name = 'lldb'
}

dap.adapters.delve = function(callback, config)
    if config.mode == 'remote' and  config.request == 'attach' then
        callback({
            type = 'server',
            host = config.host or '127.0.0.1',
            port = config.port or '38697',
        })
    else
        callback({
        type = 'server',
        port = '${port}',
        executable = {
            command = 'dlv',
            args = { 'dap', '-l', '127.0.0.1:${port}', '--log', '--log-output=dap' },
            detached = vim.fn.has("win32") == 0,
            }
        })
    end
end

dap.configurations.c = {
  {
    name = 'Launch',
    type = 'lldb',
    request = 'launch',
    program = function()
      return vim.fn.input('Path to executable: ', vim.fn.getcwd() .. '/', 'file')
    end,
    cwd = '${workspaceFolder}',
    stopOnEntry = false,
    args = function()
        return vim.fn.split(vim.fn.input('Arguments: '), ' ')
    end,
    runInTerminal = true,
  },
}

dap.configurations.zig = dap.configurations.c
dap.configurations.cpp = dap.configurations.c
dap.configurations.objc = dap.configurations.c

dap.configurations.go = {
  {
    type = "delve",
    name = "Debug",
    request = "launch",
    program = "${file}"
  },
  {
    type = "delve",
    name = "Debug test", -- configuration for debugging test files
    request = "launch",
    mode = "test",
    program = "${file}"
  },
  -- works with go.mod packages and sub packages 
  {
    type = "delve",
    name = "Debug test (go.mod)",
    request = "launch",
    mode = "test",
    program = "./${relativeFileDirname}"
  }
}
